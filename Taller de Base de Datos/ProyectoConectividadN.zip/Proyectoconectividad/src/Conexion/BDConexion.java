
package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BDConexion {
    
    
    private String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
    private String url="jdbc:sqlserver://";
    private String user="";
    private String pass="";
    private boolean Seguridad;
    
    
    public BDConexion(String Servidor,String BD){
        url=url + Servidor +":1433;databaseName=" + BD+";integratedSecurity=true";
        Seguridad=true;
    }

    public BDConexion(String Servidor,String BD, String Usuario,String Contra){
         url=url + Servidor +":1433;databaseName=" + BD;
         user=Usuario;
         pass=Contra;
    }
    
    
     public Connection conectar() throws Exception{
            Class.forName(driver);
            
              Connection con;
            if(Seguridad)
                con=(DriverManager.getConnection(url));
            else
                con=(DriverManager.getConnection(url,user,pass));
            
           
            return con;
     }  
     
}
